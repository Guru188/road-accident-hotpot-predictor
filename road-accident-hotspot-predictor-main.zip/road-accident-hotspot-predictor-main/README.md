🚦 Predicting Road Accident Hotspots Using Weather, Traffic, and Social Data

Team: Data Vigilance
Members: Mahanth V, R Abhiishek, Sujit Muthukumarasamy, Guru B

AI-based system predicting road accident hotspots using weather, traffic, and social data.
